<?php
// For Store data
session_start();

// Database Connection code Start
$servername = "localhost";
$username = "root";
$password = "";
$db_name = "login_db";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $db_name);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
echo "Connected successfully";
// Database Connection code End

// Database table and column name selection code
if(isset($_POST['loginBtn'])){
    // html email and password field selection code
    $email = $_POST['email'];
    $password = $_POST['password'];
    
    // select database table and column name line
    $select = "SELECT * FROM user_info WHERE email = '$email' AND password = '$password'";

    // execute code by query
    $execute = mysqli_query($conn, $select);

    // for data Bring up by fetch
    $fetch = mysqli_fetch_array($execute);
    // Condition Apply For check
    if($fetch){
        // echo "<script>alert('Login Successful')</script>";
        header('Location: mainWindow.php');
        // fetch email address from database to another page display
        $_SESSION['email'] = $fetch['email'];
        // fetch password from database to another page display
        $_SESSION['password'] = $fetch['password'];
    }
    else{
        echo "<script>alert('Email and Password Not Matched')</script>";
    }
}

?>


<!DOCTYPE html>
<html lang="en">
<head>
    
    <title>Login System</title>

    <style>
        .container{
            width: 600px;
            height: 400px;
            border-radius: 10px;
            background-color: green;
            margin: auto;
            padding: 10px;
        }
        .container h1{
            color: white;
            text-align: center;
        }
        form{
            text-align: center;
        }
        form input{
            width: 90%;
            height: 50px;
            border-radius: 10px;
            padding: 10px;
            font-size: 1.2rem;

        }
        form button{
            width: 90%;
            height: 70px;
            border-radius: 10px;
            padding: 10px;
            font-size: 1.4rem;
            font-weight: 700;
            background-color: blue;
            color: white;
            cursor: pointer;
            transition: 0.3s;
        }
        form button:hover{
            background-color: pink;
            color: black;
        }
        .forgetPassDiv{
            text-align: end;
            margin-top: 50px;
            margin-right: 25px;
        }
        .forgetPass{
            font-size: 1.3rem;
            text-decoration: none;
            font-style: italic;
            font-weight: 700;
            color: #fff;
            transition: 0.2s;
        }
        .forgetPass:hover{
            color: blue;
        }
    </style>
</head>
<body>

    <div class="container">
        <h1>Login System Page with PHP</h1>
        <form method="POST">
            <input type="email" name="email" placeholder="Enter Email">
            <br><br>
            <input type="password" name="password" placeholder="Enter password">
            <br><br>
            <button name="loginBtn">Login Now</button>
        </form>

        <div class="forgetPassDiv">
            <a href="forgetPassword.php" class="forgetPass">Forget Password?</a>
        </div>
    </div>

    
</body>
</html>