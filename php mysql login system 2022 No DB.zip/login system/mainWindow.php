<?php
// For Store data
session_start();
// For Secure URL / do not permission enter by url type
if($_SESSION['email'] == true){
    // after login fetch email address and password display from database into this page
    echo("<h1>Email : $_SESSION[email]</h1>");
    echo("<h1>Password : $_SESSION[password]</h1>");
} else{
    header('Location: loginPage.php');
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Document</title>
</head>
<body>

    <a href="logout.php">Logout</a>
    <h1>Welcome To Working Profile Page</h1>
    <a href="dataEntry.php">Data Entry</a>
    <h1>Change Your Password</h1>
    <a href="passwordChange.php">Password Change</a>
    
</body>
</html>
